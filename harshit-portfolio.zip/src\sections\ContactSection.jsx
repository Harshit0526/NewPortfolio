import { personal } from "../data/personal";
import { Github, Linkedin, Mail, FileDown } from "lucide-react";

export default function ContactSection() {
  return (
    <section id="contact" className="min-h-screen flex items-center px-6 py-24">
      <div className="max-w-7xl mx-auto w-full">
        <div className="bg-[#0B0B0E]/90 backdrop-blur-md border border-white/10 p-10 md:p-16 rounded">
          <div className="font-mono text-xs text-[#FF4D00] uppercase tracking-widest mb-3">
            07 // INITIATE CONNECTION
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold text-white tracking-tight">
            Let&apos;s Build Something.
          </h2>
          <p className="mt-4 font-sans text-zinc-400 max-w-2xl text-base">
            Available for entry-level Software Development Engineer (SDE), Java Developer, or Spring Boot Developer roles.
          </p>

          <div className="mt-8 flex flex-wrap gap-4 font-mono text-xs">
            <a
              href={personal.github}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-5 py-3 bg-[#FF4D00] text-white font-medium rounded hover:bg-[#e04400] transition"
            >
              <Github className="w-4 h-4" />
              GitHub
            </a>
            <a
              href={personal.linkedin}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-5 py-3 bg-zinc-900 border border-zinc-700 text-white rounded hover:border-[#FF4D00] transition"
            >
              <Linkedin className="w-4 h-4" />
              LinkedIn
            </a>
            <a
              href={`mailto:${personal.email}`}
              className="flex items-center gap-2 px-5 py-3 bg-zinc-900 border border-zinc-700 text-white rounded hover:border-[#FF4D00] transition"
            >
              <Mail className="w-4 h-4" />
              Email ({personal.email})
            </a>

            {personal.resumeUrl ? (
              <a
                href={personal.resumeUrl}
                download
                className="flex items-center gap-2 px-5 py-3 bg-white text-black font-medium rounded hover:bg-zinc-200 transition"
              >
                <FileDown className="w-4 h-4" />
                Download Resume
              </a>
            ) : (
              <span
                title="Add PDF file path to src/data/personal.js"
                className="flex items-center gap-2 px-5 py-3 bg-zinc-900/50 border border-dashed border-zinc-700 text-zinc-400 rounded cursor-not-allowed"
              >
                <FileDown className="w-4 h-4 text-[#FF4D00]" />
                Download Resume (Attach PDF in personal.js)
              </span>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
